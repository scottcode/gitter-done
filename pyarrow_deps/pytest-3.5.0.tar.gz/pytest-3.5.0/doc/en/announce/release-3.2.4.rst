pytest-3.2.4
=======================================

pytest 3.2.4 has just been released to PyPI.

This is a bug-fix release, being a drop-in replacement. To upgrade::

  pip install --upgrade pytest
  
The full changelog is available at http://doc.pytest.org/en/latest/changelog.html.

Thanks to all who contributed to this release, among them:

* Bruno Oliveira
* Christian Boelsen
* Christoph Buchner
* Daw-Ran Liou
* Florian Bruhin
* Franck Michea
* Leonard Lausen
* Matty G
* Owen Tuz
* Pavel Karateev
* Pierre GIRAUD
* Ronny Pfannschmidt
* Stephen Finucane
* Sviatoslav Abakumov
* Thomas Hisch
* Tom Dalton
* Xuan Luong
* Yorgos Pagles
* Семён Марьясин


Happy testing,
The pytest Development Team
